<?php

namespace App\Mail;

use Facade\Ignition\Middleware\AddLogs;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Address;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Queue\SerializesModels;

class PostBlog extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

   
    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('mail.blog_posted');
    }

    
    public function Envelope()
    {
        return new Envelope(
            from: new Address('martinhadiwinata@gmail.com', 'Martin'),
            subject: 'blog'
        );
    }


    
}
