<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ping</title>
</head>
<body>
    <h1>Pongkkk</h1>
    
</body>
</html><?php /**PATH /home/martin/mhwproject/resources/views/ping.blade.php ENDPATH**/ ?>