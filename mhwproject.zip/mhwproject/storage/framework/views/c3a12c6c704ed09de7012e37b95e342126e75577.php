<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
  <h1>MHW PROJECT
        <a class="btn btn-success" href="<?php echo e(url('posts/create')); ?>">Upload konten</a>
    </h1>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div class="card mb-3">
   <div class="card-body">
    <h5 class="card-title"><?php echo e($post->title); ?></h5>
    <p class="card-text"><?php echo e($post->content); ?></p>
    <p class="card-text"><small class="text-body-secondary">Last updated at <?php echo e(date("d M Y H:i", strtotime($post->created_at))); ?></small></p>
    <a href="<?php echo e(url("posts/$post->id")); ?>" class="btn btn-primary">Selengkapnya</a>
    <a href="<?php echo e(url("posts/$post->id/edit")); ?>" class="btn btn-warning">UPDATE</a>
  
  </div>
</div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/martin/mhwproject/resources/views/posts/index.blade.php ENDPATH**/ ?>