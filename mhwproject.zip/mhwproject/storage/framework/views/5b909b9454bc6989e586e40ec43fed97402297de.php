<?php $__env->startSection('title', 'Detail'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <article class="blog-post">
            <h2 class="blog-post" mb-1><?php echo e($post->title); ?></h2>
            <p class="blog-post-meta"><?php echo e(date("d M Y H:i", strtotime($post->created_at))); ?></p>
            <p><?php echo e($post->content); ?></p>

            <small class="text-muted"><?php echo e($total_comments); ?> Komentar</small>

            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb3">
                <div class="card-body">
                    <p style="font-size: 8pt"><?php echo e($comment->comment); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </article>
        <a class="btn btn-dark" href="<?php echo e(url ("posts")); ?>">Kembali</a>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/martin/mhwproject/resources/views/posts/show.blade.php ENDPATH**/ ?>