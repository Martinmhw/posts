<?php $__env->startSection('title', 'Register'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-4"></div>

        <div class="card cold-md-4">
            <div class="card-body">
                <h1 class="text-center">Register</h1>
                <?php if(session()->has('error_message')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get('error_message')); ?>

                </div>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(url('register')); ?>">
                <?php echo csrf_field(); ?>

                <div class="row-3">
                <label for="text" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name">
                <?php if($errors->has('names')): ?>
                <span class="text-danger"><?php echo e($errors->firs('name')); ?></span>
                <?php endif; ?>
               </div> 
               
               <div class="row-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email">
                <?php if($errors->has('name')): ?>
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
               </div> 

               <div class="row-3">
                <label for="text" class="form-label">Password</label>
                <input type="text" class="form-control" id="password" name="password">
                <?php if($errors->has('name')): ?>
                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                <?php endif; ?>
               </div> 
               
               <div class="mb-3">
                <label for="passwrod_confirmation" class="form-label">Konfirmasi password</label>
                <input type="password" class="form-control" id="password" name="password_confirmation">
               </div>

               <div class="mb-3">
                <button type="submit" class="btn btn-primary">Login</button>
               </div>

                </form>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/martin/mhwproject/resources/views/Auth/register.blade.php ENDPATH**/ ?>