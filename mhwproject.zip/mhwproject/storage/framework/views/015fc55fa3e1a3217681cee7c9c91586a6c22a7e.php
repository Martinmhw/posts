<header class="p-3 text-bg-dark mb-3">
    <div class="container">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          <li><a href="#" class="nav-link px-2 text-secondary">Home</a></li>
        </ul>
        <div class="text-end">
          <?php if(Auth::check()): ?>
          <a href="<?php echo e(url('logout')); ?>" class="btn btn-outline-light me-2">Logout</a>
          <?php else: ?>
          <a href="<?php echo e(url('login')); ?>" class="btn btn-outline-light me-2">Login</a>
          <a href="<?php echo e(url('register')); ?>" class="btn btn-outline-light me-2">Register</a>
          
          <?php endif; ?>
        </div>
      </div>
    </div>
  </header>
    <div class="container">
<?php /**PATH /home/martin/mhwproject/resources/views/layouts/app/header.blade.php ENDPATH**/ ?>