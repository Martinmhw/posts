<?php $__env->startSection('title', 'Update'); ?>

<?php $__env->startSection('content'); ?>

<h1>Upload Postingan</h1>
<form method="POST" action="<?php echo e(url("posts/$post->id")); ?>" class="form-control">
  <?php echo method_field('PATCH'); ?>
  <?php echo csrf_field(); ?>
  
<div class="mb-3">
  <label for="title" class="form-label">Judul</label>
  <input type="text" class="form-control" id="title" name="title" value="<?php echo e($post->title); ?>">
</div>
<div class="mb-3">
  <label for="content" class="form-label">Konten</label>
  <textarea class="form-control" id="content" name="content" rows="3"><?php echo e($post->content); ?></textarea>
</div>
<button type="submit" class="btn btn-primary">Simpan</button>

</form>
<form method="post" action="<?php echo e(url("posts/$post->id")); ?>">
<?php echo method_field('DELETE'); ?>
<?php echo csrf_field(); ?>
<button type="submit" class="btn btn-danger">Hapus</button>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/martin/mhwproject/resources/views/posts/edit.blade.php ENDPATH**/ ?>